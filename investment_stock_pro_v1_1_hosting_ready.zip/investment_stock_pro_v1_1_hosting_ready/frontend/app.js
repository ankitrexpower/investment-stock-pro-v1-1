// After backend deploy, paste Render backend URL here, for example:
// const API_BASE = "https://investment-stock-pro-v11.onrender.com";
const API_BASE = "http://localhost:8000";
let DATA = {D:[],W:[],M:[]};
let active='D';
function show(tf, el){active=tf;document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));if(el)el.classList.add('active');render();}
function render(){const rows=document.getElementById('rows');const list=DATA[active]||[];if(!list.length){rows.innerHTML='<tr><td colspan="4">No SETUP</td></tr>';return;}rows.innerHTML=list.map(r=>`<tr><td><b>${r.stock}</b></td><td>${r.total_holding.toFixed(2)}%</td><td>${r.cci.toFixed(2)}</td><td><span class="badge">SETUP</span></td></tr>`).join('');}
async function scan(){const msg=document.getElementById('msg');msg.textContent='Scanning...';try{const res=await fetch(API_BASE+'/scan');if(!res.ok)throw new Error('Backend not responding');const j=await res.json();DATA=j.results;document.getElementById('total').textContent=j.total_stocks;document.getElementById('qualified').textContent=j.qualified_stocks;document.getElementById('setup').textContent=j.total_setup;document.getElementById('last').textContent=j.last_scan;msg.textContent='Scan complete';render();}catch(e){msg.innerHTML='<span class="err">Backend link connect nahi hai. Pehle backend host karke app.js me API_BASE update karo.</span>';}}
